<script>
  import { polygonArea } from "d3";

  import * as d3 from "d3";

  let sliderValue = 0; // El valor del slider, desde 0 hasta 100

  // Función para calcular la extensión de la línea superior
  const calculateWidth = (value) => {
    return (value / 100) * 150; // Esto hace que la línea superior crezca hasta 150px
  };
</script>

<main>
  <div class="header">
    <div class="nombres">
      <p>Candelaria Victorica</p>
      <p>Sofía Rolón</p>
      <p>Martina Monastra</p>
    </div>

    <h3 class="headline">
      <b>El Deporte Como Escultura Corporal</b>
    </h3>
    <p class="bajada">
      El deporta ha moldeado los cuerpos de las personas desde hace muchos años.
      Acompáñanos a ver los cambios corporales según los deportes de alto
      rendimiento.
    </p>
  </div>

  <div class="coffes-container">
    <div class="column-wrapper">
      <div class="persona">
        <div id="torso">
          <img
            src="public/images/Torzo min.svg"
            alt="persona"
            style="width: 65%;"
          />
        </div>
        <div id="brazo">
          <img src="public/images/Brazo min.svg" alt="brazo" />
        </div>
        <div id="pierna">
          <img src="public/images/Piernas min.svg" alt="brazo" />
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <!-- Rectángulo deformable -->
    <div
      class="rectangle"
      style="clip-path: polygon(50% 0%, {50 -
        calculateWidth(sliderValue) / 2}% 100%, {50 +
        calculateWidth(sliderValue) / 2}% 100%);"
    ></div>
  </div>

  <!-- Slider para controlar la deformación -->
  <input
    type="range"
    min="35"
    max="100"
    bind:value={sliderValue}
    class="slider"
  />
</main>

<style>
  /* Estilos del contenedor del rectángulo */
  .container {
    width: 300px;
    height: 400px;
    margin: 50px auto;
    position: relative;
  }

  /* Estilos del rectángulo */
  .rectangle {
  position: absolute;
  top: 50px; /* Desplaza el rectángulo hacia abajo */
  left: 0;
  width: 100%;
  height: 100%;
  background-color: #3498db;
  transition: clip-path 0.3s ease, transform 0.3s ease;
  transform: rotate(180deg); /* Aquí aplicas la rotación */
}

  /* Slider */
  .slider {
    width: 100%;
    margin-top: 20px;
  }

  #torso {
    position: absolute;
    margin-left: 40px;
  }
  #brazo {
    position: absolute;
    margin-top: 80px;
  }

  #pierna {
    position: absolute;
    margin-top: 220px;
  }

  .coffes-container {
    display: flex;
    gap: 50px;
  }
  .column-wrapper {
    position: relative;
    width: 160px;
    height: 200px;
    /* background-color: #ccc;
  border: black 1px solid; */
  }

  .nombres {
    text-decoration: none;
    display: flex;
    gap: 20px;
  }
  .header {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    /* margin-top: 20px;
  margin-bottom: 80px; */
  }
  .headline {
    font-size: 40px;
    font-weight: 300;
    line-height: 1.2;
    text-align: center;
    margin: 20px;
  }
  .bajada {
    font-size: 24px;
    font-weight: 300;
    text-align: center;
    margin: 10px;
  }
  .headline b {
    display: block;
  }
</style>